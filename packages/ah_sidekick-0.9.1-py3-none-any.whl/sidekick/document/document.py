import warnings
from dataclasses import dataclass
from enum import Enum
from logging import getLogger
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Callable, Optional, Set, Tuple, Union

logger = getLogger(__name__)
try:
    import magic
    from pdf2image import convert_from_path
    from PIL import Image
    from PIL.Image import DecompressionBombWarning

except ImportError as e:
    raise ImportError(
        'Dependencies for the Document interface were not installed. '
        'Did you remember to `pip install sidekick[document]`?'
    ) from e

# Convert DecompressionBombWarning into an error to avoid getting DDOSed by compression bombs
warnings.simplefilter('error', DecompressionBombWarning)


@dataclass(frozen=True)
class _FileTypeConfig:
    """Configuration items for a FileType."""

    # A set of MIME-types that map to this FileType
    mime_types: Set[str]

    # A set of file extensions (without a leading period) that map to this FileType
    extensions: Set[str]


class FileType(Enum):
    """The supported file-types and their associated MIME types."""
    BMP = _FileTypeConfig(mime_types={'mime/bmp', 'image/bmp'}, extensions={'bmp'})

    JPEG = _FileTypeConfig(
        mime_types={'mime/jpeg', 'image/jpeg'}, extensions={'jpg', 'jpeg'}
    )

    PDF = _FileTypeConfig(mime_types={'application/pdf'}, extensions={'pdf'})

    PNG = _FileTypeConfig(mime_types={'mime/png', 'image/png'}, extensions={'png'})

    PPM = _FileTypeConfig(mime_types={'image/x-portable-pixmap'}, extensions={'ppm'})

    TIFF = _FileTypeConfig(
        mime_types={'mime/tiff', 'image/tiff'}, extensions={'tif', 'tiff'}
    )

    @classmethod
    def from_MIME(cls, mime_type: Union[str, bytes]) -> 'FileType':
        """Get the FileType corresponding to the given MIME string."""
        if isinstance(mime_type, bytes):
            mime_type = mime_type.decode()
        for t in cls:
            if mime_type in t.value.mime_types:
                return t
        raise ValueError(f"{mime_type} is not a supported file-type.")

    @classmethod
    def from_extension(cls, extension: str) -> 'FileType':
        """Get the FileType corresponding to the given file extension."""
        extension = extension.lower().lstrip(
            '.'
        )  # Remove leading periods from an extension
        for t in cls:
            if extension in t.value.extensions:
                return t
        raise ValueError(f"{extension} is not a supported file-type.")

    @classmethod
    def of(cls, local_image_path: Union[str, Path]) -> 'FileType':
        """
        Parse the FileType of the given file.

        Args:
            local_image_path: The path to the file.

        Returns:
            The FileType of the given file.

        Raises:
            ValueError, if the file's MIME type isn't supported.
        """
        extension = Path(local_image_path).suffix

        try:
            return cls.from_MIME(cls.get_MIME_type(str(local_image_path)))
        except ValueError as e:
            if extension:
                try:
                    return cls.from_extension(extension)
                except ValueError:
                    pass
            raise e

    @staticmethod
    def get_MIME_type(path: str) -> str:
        """Get the MIME-type of a file."""
        return magic.from_file(path, mime=True)


class Document(object):
    """An interface for document data in containerized functions, including various PDF and image formats."""

    def __init__(
        self,
        path: Union[Path, str],
        file_type: Optional[FileType] = None,
        preprocess_fn: Optional[Callable[[Image.Image], Any]] = None,
        mode: str = 'L',
        dpi: int = 300,
        size: Optional[Tuple[int, int]] = None,
        size_limit: int = None,
        thread_count: Optional[int] = None,
    ) -> None:
        """
        Initialize and lazy-load a Document from file.

        Args:
            path:           The path to the document on file.
            file_type:      The FileType of the document, if it shouldn't be extracted from the MIME metadata.
            preprocess_fn:  A function that will be applied to each Image in the Document on iteration.
            mode:           The mode in which to open images in the Document.
            dpi:            The DPI to use when converting PDF pages to images.
            size:           Size (w, h), (w, None) or (None, h) the images will be resized to. If one dimension is None it will be scaled to preserve aspect ratio.
            size_limit:     The maximum size of an image in the Document. Images larger than this will be resized to fit.
            thread_count:   Number of threads used to read multipage PDFs.

        Raises:
            ValueError, if `file_type` is not specified and the Document's detected MIME type is not supported.
        """
        self.path = Path(path)
        self.type = file_type or FileType.of(
            self.path
        )  # Identify the file-type of the Document
        self.preprocess_fn = preprocess_fn
        self.mode = mode
        self.size_limit = size_limit
        self.output_size = size
        self._image_dir = TemporaryDirectory()
        self.image_paths = []

        # If the Document is a PDF, convert each of its pages to an image on disk for lazy-loading.
        if self.type is FileType.PDF:
            if thread_count is None:
                _thread_count = -1
            else:
                _thread_count = thread_count
            self.image_paths = convert_from_path(
                path,
                dpi=dpi,
                size=size,
                thread_count=_thread_count,
                output_folder=self._image_dir.name,
                output_file='page',
                paths_only=True
            )

        # If the Document is a multi-page TIFF, convert each of its pages to an image on disk for lazy-loading (or just
        #  use the original path if it only contains a single image).
        elif self.type is FileType.TIFF:
            _img = Image.open(self.path)
            if hasattr(_img, 'n_frames'):
                for i in range(_img.n_frames):
                    _filename = f"{self._image_dir.name}/{i}.png"
                    _img.seek(i)
                    _img.save(_filename)
                    self.image_paths.append(_filename)
            else:
                self.image_paths.append(str(self.path))

        # Treat everything else as a regular single image
        else:
            path = self.path
            self.image_paths.append(str(path))

    def __iter__(self):
        """Lazily load each image contained in the Document."""
        for path in self.image_paths:
            yield self._load_image(path)

    def __len__(self):
        """Get the number of images contained in the Document."""
        return len(self.image_paths)

    def __getitem__(self, key):
        """Index or slice the pages of the Document."""
        if isinstance(key, slice):
            return [self._load_image(path) for path in self.image_paths[key]]
        else:
            path = self.image_paths[key]
            return self._load_image(path)

    def __del__(self):
        """Clean up the temporary directory of images when the Document is deleted."""
        if hasattr(self, '_image_dir'):
            self._image_dir.cleanup()

    def _load_image(self, path: Union[str, Path]) -> Any:
        """Load an image from file and preprocess it."""
        image = Image.open(path).convert(self.mode)
        size: Tuple[int, int] = image.size
        min_size = min(size)
        logger.debug(f"Loaded image {path} with size {size}.")

        if self.output_size is not None:
            # if output size is specified, resize image.
            image = self._resize_image(image, self.output_size)
        elif (self.size_limit is not None) and (min_size > self.size_limit):
            # If the image is too large, resize it to fit within the size limit.
            ratio = size[0] / size[1]
            if size[0] > size[1]:
                new_size = (self.size_limit, int(self.size_limit / ratio))
            else:
                new_size = (int(self.size_limit * ratio), self.size_limit)
            logger.debug(f"Resizing image {path} to {new_size} to fit size limit.")
            image = image.resize(new_size, resample=Image.LANCZOS)

        if self.preprocess_fn:
            image = self.preprocess_fn(image)
        return image

    def _resize_image(self, image: Image.Image, size: Tuple[int, int]) -> Image.Image:
        """Resize an image on a path or in memory."""

        t_width, t_height = size
        i_width, i_height = image.size
        if t_width is None and t_height is not None:
            t_width = int(i_width * t_height / i_height)
        elif t_height is None and t_width is not None:
            t_height = int(i_height * t_width / i_width)
        elif t_height is None and t_width is None:
            return image

        image = image.resize((t_width, t_height), resample=Image.LANCZOS)
        return image
