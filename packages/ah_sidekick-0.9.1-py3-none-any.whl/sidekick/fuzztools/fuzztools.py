"""Edit distance based ensembling tools.

This module presents some tools to compute central elements and regex patterns from collections of candidates.

Example:
    Compute the central element of the following candidates like so::

        $ candidates = ["sitting", "kitten", "knitting"]
        $ es = EnsembledString(candidates)
        $ print(es.central_candidate)
        $ print(es.confidence)
        $ print(es.get_regex())
        $ print(es.get_wildcard_string())
        $ print(es.get_character_confidences())
"""
import re
from math import ceil
from itertools import product
from functools import reduce

import numpy as np
import rapidfuzz


def normalized_levenshtein_distance(a, b, ignore_case=True):
    """Compute normalized levenshtein distance. Return a value between 0.0 and 1.0 where 0.0 is a perfect match.

    Args:
        a (str): The first string.
        b (str): The second string.
        ignore_case (bool, optional): Whether to consider text case when computing distance.
    """
    if ignore_case:
        a, b = a.lower(), b.lower()
    similarity = (
        rapidfuzz.string_metric.normalized_levenshtein(
            a, b, weights=(1, 1, 1), score_cutoff=0
        )
        / 100.0
    )
    return 1.0 - similarity


def normalized_levenshtein_paths(a, b, ignore_case=True):
    """Compute normalized levenshtein distance. Return the edit paths to get from a to b.

    Args:
        a (str): The first string.
        b (str): The second string.
        ignore_case (bool, optional): Whether to consider text case when computing distance.
    """
    if ignore_case:
        a, b = a.lower(), b.lower()
    paths = [rapidfuzz.string_metric.levenshtein_editops(a, b)]
    enriched_paths = []
    for path in paths:
        enriched_path = []
        _a = list(a)
        _b = list(b)
        for operation, src_idx, dst_idx in path:
            if operation == "replace":
                enriched_path.append((operation, src_idx, dst_idx, _b[dst_idx]))
            elif operation == "delete":
                enriched_path.append((operation, src_idx, dst_idx, _a[src_idx]))
            elif operation == "insert":
                enriched_path.append((operation, src_idx, dst_idx, _b[dst_idx]))
            else:
                raise ValueError(
                    f"edit operation '{operation}' is not one of 'replace', 'delete', 'insert'."
                )
        enriched_paths.append(enriched_path)

    return enriched_paths


class TrackedElement:
    """Wrapper for holding an element of a sequence while tracking edit ops on the element."""

    def __init__(self, value, optional=None, position=None, is_insertion=False):
        """
        Initialize the wrapper.

        Args:
            value (str): The wrapped element.
            optional (bool, optional): Whether the wrapped element is intrinsically optional.
            position (int, optional): Where in an original sequence the element appears.
            is_insertion (bool, optional): Indicates that this element was created as an insertion.
        """
        self.value = value
        self.position = position
        self.is_insertion = is_insertion
        self._optional = optional or is_insertion
        self._alternatives = [value]
        self._deletions = 0
        self._insertions = 1 if is_insertion else 0
        self._trace_active = False
        self._edited_this_trace = None
        self._times_kept = 0
        self._times_traced = 0

    def start_trace(self):
        """Start tracking a trace. Within a trace, the element can be edited
        0 or 1 times. If an edit is not performed before the trace is completed,
        a "keep" is tracked. This enables confidence calculations by tracking
        how many times a character didn't need changing.
        """
        assert (
            not self._trace_active
        ), f"start_trace() was called on {repr(self)} but a trace is already active."
        self._edited_this_trace = False
        self._trace_active = True

    def complete_trace(self):
        """Complete a trace. If the element was not edited during the trace, a
        "keep" will be tracked so that confidence calculations can consider how
        many times a character didn't need changing.
        """
        assert (
            self._trace_active
        ), f"complete_trace() was called on {repr(self)} but no trace is active."
        if not self._edited_this_trace:
            self._times_kept += 1
        self._edited_this_trace = None
        self._trace_active = False
        self._times_traced += 1

    def register_replacement(self, alternative):
        """Register a replacement edit on this element.

        Args:
            alternative: The alternative element that is being edited into.
        """
        assert (
            self._trace_active
        ), f"register_replacement called on {repr(self)} but no trace is active."
        assert (
            not self._edited_this_trace
        ), f"register_replacement called on {repr(self)} but an edit has already been made this trace."
        self._alternatives.append(alternative)

    def register_deletion(self):
        """Register a deletion edit on this element."""
        assert (
            self._trace_active
        ), f"register_deletion called on {repr(self)} but no trace is active."
        assert (
            not self._edited_this_trace
        ), f"register_deletion called on {repr(self)} but an edit has already been made this trace."
        self._deletions += 1
        self._edited_this_trace = True

    @property
    def alternatives(self):
        """Return the different alternatives this element has been edited into."""
        return sorted(set(self._alternatives))

    @property
    def deletions(self):
        """Return the number of times this element has been deleted."""
        assert not self._trace_active, "Active traces should be ended before accessing tracked quantities."
        return self._deletions

    @property
    def insertions(self):
        """Return the number of times this element has been deleted. These are always 1 unless elements have been added."""
        assert not self._trace_active, "Active traces should be ended before accessing tracked quantities."
        return self._insertions

    @property
    def times_kept(self):
        """Return the number of times this element was not edited within a trace."""
        assert not self._trace_active, "Active traces should be ended before accessing tracked quantities."
        return self._times_kept

    @property
    def edits(self):
        """Return the number of edits registered to this element."""
        assert not self._trace_active, "Active traces should be ended before accessing tracked quantities."
        return len(self._alternatives) + self._deletions

    @property
    def optional(self):
        """Whether this element is either intrinsically optional or has ever been deleted."""
        return self.is_insertion or self._optional or self.deletions > 0

    @property
    def regex(self):
        """Return a regex matching any alternatives registered to this element and a ? if optional."""
        r = "".join([re.escape(c) for c in sorted(set(self.alternatives))])
        if len(self.alternatives) > 1:
            r = f"[{r}]"
        if self.optional:
            r += "?"
        return r

    @property
    def edit_ratio(self):
        return (len(self._alternatives) + self._deletions) / (self._times_kept + self._insertions)

    def __add__(self, other):
        """Combine two TrackedElement instances into one containing the total edits, deletions or values.

        Note:
            The TrackedElement.value assigned is the most common alternative encountered.
        """
        if (
            (self.position is not None)
            and (other.position is not None)
            and (self.position != other.position)
        ):
            raise ValueError(
                f"It doesn't make sense to add two elements in different explicit positions. Got {self.position} and {other.position}. They need to have either the same position or at least one undefined position."
            )
        if self.is_insertion != other.is_insertion:
            raise ValueError(
                f"Adding insertions to non-insertions is problematic because of how confidence is computed. Got self {self.is_insertion} and other {self.is_insertion}."
            )

        all_alternatives = self._alternatives + other._alternatives
        new = TrackedElement(
            value=max(set(all_alternatives), key=all_alternatives.count),
            optional=self._optional and other._optional,
            position=self.position or other.position,
            is_insertion=self.is_insertion,
        )
        new._alternatives = all_alternatives
        new._deletions = self._deletions + other._deletions
        new._deletions = self._deletions + other._deletions
        new._insertions = self._insertions + other._insertions
        return new

    def __str__(self):
        """Return the regex representation of this element."""
        return self.regex

    def __repr__(self):
        """Return a developer-friendly representation of this element."""
        return f"{self.__class__.__name__}(value={self.value}, position={self.position}, is_insertion={self.is_insertion}, _optional={self._optional}, _alternatives={self._alternatives}, _deletions={self._deletions}, _insertions={self._insertions}, regex={self.regex}"


class EnsembledString:
    def __init__(self, candidates, p=1.0, ignore_case=True):
        """Create an instance of an ensembled string from a list of candidates.

        Args:
            candidates (:obj:`list`): List of candidates to consider.
            p (float, optional): A value between 0.0 and 1.0. If < 1.0, only consider the p*100:th percentile of paths when producing the regex pattern.
            ignore_case (bool, optional): Whether to ignore text case.
        """
        self.candidates = candidates
        self.p = p
        self.ignore_case = ignore_case

        if ignore_case:

            def pre(x):
                return x.lower()

        else:

            def pre(x):
                return x

        similarity_matrix = np.zeros(
            shape=(len(candidates), len(candidates)), dtype=np.float32
        )
        for i, j in product(list(range(len(candidates))), repeat=2):
            (similarity_matrix[i, j], similarity_matrix[j, i],) = [
                normalized_levenshtein_distance(
                    candidates[i], candidates[j], ignore_case=ignore_case
                )
            ] * 2
        scores = np.sum(similarity_matrix, axis=0) / (max(len(candidates) - 1, 1))
        best_index = np.argmin(scores)

        self.confidence = 1.0 - scores[best_index]
        self.central_candidate = pre(candidates[best_index])

        paths = sum(
            [
                normalized_levenshtein_paths(
                    self.central_candidate, candidate, ignore_case=True
                )
                for candidate in candidates
            ],
            [],
        )
        paths = sorted(paths, key=len)
        paths = paths[: ceil(len(paths) * p)]

        self.base_characters = [
            TrackedElement(pre(c), optional=False, position=i)
            for i, c in enumerate(self.central_candidate)
        ]
        self._insertions = {}

        for path in paths:
            for c in self.base_characters:
                c.start_trace()
            scratch = [c for c in self.base_characters]
            for operation, src_idx, dst_idx, char in path:
                char = pre(char)
                if operation == "replace":
                    scratch[src_idx].register_replacement(char)
                elif operation == "delete":
                    scratch[src_idx].register_deletion()
                elif operation == "insert":
                    if src_idx > 0:
                        insertion_position = (
                            scratch[src_idx - 1].position + 1
                        )  # Look at previous index
                    elif (
                        len(scratch) > 0
                    ):  # We know src_idx 0 so we just need that scratch is not empty
                        insertion_position = scratch[src_idx].position
                        # Look at current index which we will insert in front of
                        # this will cause there to be mutliple words with the same index
                        # however this is intended for us to keep track of where insertions
                        # happen within the original self.base_characters.
                    else:
                        insertion_position = 0  # We're inserting in an empty string
                    insertion_element = TrackedElement(
                        char,
                        optional=True,
                        position=insertion_position,
                        is_insertion=True,
                    )
                    if insertion_position in self._insertions:
                        self._insertions[insertion_position].append(insertion_element)
                    else:
                        self._insertions[insertion_position] = [insertion_element]
                else:
                    raise ValueError(
                        f"edit operation '{operation}' is not one of 'replace', 'delete', 'insert'."
                    )
            for c in self.base_characters:
                c.complete_trace()

    @property
    def insertions(self):
        """Return a dictionary {position<int>:element<TrackedElement>} describing
        the recorded insertion operations done as this string has been traced.
        """
        return {i:reduce(lambda a, b: a + b, self._insertions[i]) for i in self._insertions.keys()}

    def get_traced_string(self, maximal=True):
        """Return this string as a list of tracked elements.

        Args:
            maximal (bool, optional): If maximal is True all insertions are included in the sequence (but usually with a low confidence).
        """
        base_string = [c for c in self.base_characters]

        if maximal:
            n_insertions = 0
            for i in sorted(self._insertions.keys()):
                base_string.insert(
                    i + n_insertions, reduce(lambda a, b: a + b, self._insertions[i])
                )
                n_insertions += 1

        return base_string

    def get_regex(self, maximal=True):
        """Produce a regex pattern by starting at a central element s and traversing along the levenshtein edit paths.

        Args:
            maximal (bool, optional): If maximal is True all insertions are included in the regex (but usually with a low confidence).
        """
        return "".join([c.regex for c in self.get_traced_string(maximal=maximal)])

    def get_string(self, maximal=True):
        """Get the string values from the ensembled string such that they
        correspond to confidences retur6ned by `get_character_confidence`.

        Notes:
            This is different from EnsembledString.central_candidate. In most cases you're likely looking for `central_candidate`.

        Args:
            maximal (bool, optional): If maximal is True all insertions are included in the sequence (but usually with a low confidence).
        """
        return "".join([c.value for c in self.get_traced_string(maximal=maximal)])

    def get_character_confidence(self, maximal=True):
        """Return a list of confidences for each element in the EnsembledString.

        Args:
            maximal (bool, optional): If maximal is True all insertions are included in the sequence (but usually with a low confidence).
        """
        return [1/(c.edit_ratio*len(self.candidates)) for c in self.get_traced_string(maximal=maximal)]

    def get_wildcard_string(self, p=0.5, maximal=True, respect_counts=False, format="regex"):
        """Return a wildcard string where characters with a confidence < p are
        replaced by wildcards.

        Args:
            p (float, optional): A value between 0.0 and 1.0 indicating below which confidence a character gets replaced by a wildcard.
            maximal (bool, optional): If maximal is True all insertions are included in the sequence (but usually with a low confidence).
            respect_counts (book, optional): If respect_counts is true single-character wildcards are used instead of "0-or-more" wildcards.
            format (string): {"regex", "sql", "lucene"} Indicate which wildcard format to use. e.g "sql" uses `_` and `%` while regex uses `.?` and `.*`.
        """

        if format.lower() in ("regex","re"):
            single_wildcard = ".?"
            multi_wildcard = ".*"
            start_end = ("", "")
            preprocessor = re.escape
        elif format.lower() in ("sql", "sequel"):
            single_wildcard = "_"
            multi_wildcard = "%"
            start_end = ("", "")
            def preprocessor(s):
                s = "".join([re.escape(c) if c in ("\\",) else c for c in s])
                for c in (r"[", r"]"):
                    s = s.replace(c, "\\" + c)
                s = s.replace("%", "[%]").replace("_", "[_]")
                return s
        elif format.lower() in ("es", "kibana", "lucene", "elasticsearch"):
            single_wildcard = ".?"
            multi_wildcard = ".*"
            start_end = ("/", "/")
            def preprocessor(s):
                s = re.escape(s)
                for c in (r"+", r"-", r"&", r"|", r"!", '"', ":", "/"):
                    s = s.replace(c, "\\" + c)
                return s
        else:
            raise ValueError(f"format '{format}' not recognized. Use 'regex' or 'sql'.")

        string = self.get_string(maximal=maximal)
        confidences = self.get_character_confidence(maximal=maximal)

        wildcard_string = []
        wildcard_buffer = []
        for character, confidence in zip(string, confidences):
            if confidence >= p:
                if wildcard_buffer:
                    if respect_counts:
                        wildcard_string += wildcard_buffer
                    else:
                        wildcard_string.append(multi_wildcard)
                    wildcard_buffer = []
                wildcard_string.append(preprocessor(character))
            else:
                wildcard_buffer.append(single_wildcard)
        if wildcard_buffer:
            if respect_counts:
                wildcard_string += wildcard_buffer
            else:
                wildcard_string.append(multi_wildcard)
            wildcard_buffer = []

        return start_end[0] + "".join(wildcard_string) + start_end[1]
