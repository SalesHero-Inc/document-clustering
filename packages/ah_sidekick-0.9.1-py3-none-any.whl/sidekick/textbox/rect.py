import math
from typing import TYPE_CHECKING, Callable, Generator, List, Optional, Tuple
from uuid import uuid4

try:
    if TYPE_CHECKING:
        from PIL import Image

except ImportError as e:
    raise ImportError(
        "Dependencies for textbox extraction were not installed. "
        "Did you remember to `pip install sidekick[textbox]`?"
    ) from e


class Point(object):
    """A framework for representing a 2D point in an image."""

    def __init__(self, x: int, y: int) -> None:
        """Instantiate a point with a pair of (x, y) co-ordinates."""
        self.x, self.y = x, y

    def __str__(self) -> str:
        return "{0:6.1f}, {1:6.1f}".format(self.x, self.y)

    def __eq__(self, obj: Optional["Point"]) -> bool:
        if obj:
            return self.tuple == obj.tuple
        return False

    @property
    def tuple(self) -> Tuple[int, int]:
        """A tuple of the Point's co-ordinates."""
        return self.x, self.y

    def distance_to_point(self, other: "Point") -> float:
        """Calculate the distance to another Point."""
        return math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)

    def faces_line(self, line: Tuple["Point", "Point"]) -> bool:
        """TODO: What does this mean?"""
        a = line[0].distance_to_point(line[1])
        b = line[0].distance_to_point(self)
        c = line[1].distance_to_point(self)
        ang1, ang2 = angle(b, a, c), angle(c, a, b)
        if (ang1 > math.pi / 2) or (ang2 > math.pi / 2):
            return False
        return True


class Rect(object):
    """A framework for representing and operating on bounding boxes within a document."""

    def __init__(
        self,
        x: int,
        y: int,
        w: int,
        h: int,
        text: Optional[str] = None,
        children: Optional[List["Rect"]] = None,
        payload: Optional[dict] = None,
        id_: Optional[str] = None,
    ) -> None:
        """
        Instantiate a Rect.

        Args:
            x:          The x-coordinate of the top-left corner of the bounding box.
            y:          The y-coordinate of the top-left corner of the bounding box.
            w:          The width of the bounding box (`x` + `w` is the right end of the box on the document).
            h:          The height of the bounding box (`y` + `h` is the "bottom" end of the box on the document).
            text:       The text extracted from the bounding box region.
            children:   Other `Rect` instances merged into this instance.
            payload:    Additional metadata about the bounding box.
            id_:        A string to uniquely identify the bounding box.
        """
        self.x, self.y, self.w, self.h = x, y, w, h
        self.a = self.w * self.h
        self.id_ = id_ or uuid4().hex
        self.children = children or []
        self._text = text
        self.payload = payload or {}

    def __repr__(self):
        return (
            "{0}, id={1}, x,y,w,h={2}, text={3!r}, payload={4}, children={5}>".format(
                str(type(self))[:-1],
                self.id_,
                (self.x, self.y, self.w, self.h),
                self.text,
                self.payload,
                [repr(child) for child in self.children],
            )
        )

    def __str__(self):
        return "({0}) {1}: {2!r}".format(
            self.id_, (self.x, self.y, self.w, self.h), self.text
        )

    def __iter__(self) -> Generator[Point, None, None]:
        """Iterate through the four corner points of the Rect, clockwise from the top-left."""
        yield self.l_top
        yield self.r_top
        yield self.r_bot
        yield self.l_bot

    def __hash__(self) -> int:
        return hash((self.x, self.y, self.w, self.h, self.text))

    def __eq__(self, other) -> bool:
        return hash(self) == hash(other)

    def __ne__(self, other) -> bool:
        return not (self == other)

    @property
    def text(self):
        """The text contained within the bounding box, aggregated from child boxes if necessary."""
        if not self._text and self.children:
            return "\n".join(child.text or "" for child in self.children).strip()
        return self._text or ""

    @property
    def bounding_box(self):
        return [self.x, self.y, self.x + self.w, self.y + self.h]

    @text.setter
    def text(self, value: Optional[str]):
        """Set a new value for the Rect instance's text."""
        self._text = value

    @property
    def confidence(self) -> Optional[float]:
        """The confidence level of the bounding box."""
        return self.payload.get("tesseract_confidence")

    @property
    def x2(self) -> int:
        """The x-coordinate of the right side of the bounding box."""
        return self.x + self.w

    @property
    def y2(self) -> int:
        """The y-coordinate of the bottom side of the bounding box."""
        return self.y + self.h

    @property
    def l_top(self) -> Point:
        """The top-left Point of the Rect."""
        return Point(self.x, self.y)

    @property
    def r_top(self) -> Point:
        """The top-right Point of the Rect."""
        return Point(self.x2, self.y)

    @property
    def r_bot(self) -> Point:
        """The bottom-right Point of the Rect."""
        return Point(self.x2, self.y2)

    @property
    def l_bot(self) -> Point:
        """The bottom-left Point of the Rect."""
        return Point(self.x, self.y2)

    @property
    def center(self) -> Point:
        """The Point at the center of the Rect."""
        return Point(self.x + (self.w // 2), self.y + (self.h // 2))

    def iter_edges(self) -> Generator[Tuple[Point, Point], None, None]:
        """Iterate through the four edges of the Rect, clockwise from the top."""
        yield self.l_top, self.r_top
        yield self.r_top, self.r_bot
        yield self.r_bot, self.l_bot
        yield self.l_bot, self.l_top

    def copy(
        self,
        x: Optional[int] = None,
        y: Optional[int] = None,
        w: Optional[int] = None,
        h: Optional[int] = None,
        text: Optional[str] = None,
        children: Optional[List["Rect"]] = None,
        payload: Optional[dict] = None,
    ) -> "Rect":
        """
        Generate a new `Rect` identical to the instance but with a new ID and
        some attributes optionally overridden.
        """
        return self.__class__(
            x=x or self.x,
            y=y or self.y,
            w=w or self.w,
            h=h or self.h,
            text=text or self._text,
            children=children or [c.copy() for c in self.children],
            payload=payload or self.payload,
        )

    def grow(self, length: int, direction: str) -> "Rect":
        """Generate a new 'Rect' that is extended by `length` pixels in the `direction` direction."""
        direction = direction.upper()
        if direction == "UP":
            return self.copy(y=self.y - length, h=self.h + length)
        elif direction == "DOWN":
            return self.copy(h=self.h + length)
        elif direction == "LEFT":
            return self.copy(x=self.x - length, w=self.w + length)
        elif direction == "RIGHT":
            return self.copy(w=self.w + length)

        raise ValueError(
            "Unrecognized direction for `Rect` growing: {}".format(direction)
        )

    def distance_to(self, other: "Rect") -> float:
        """Calculate the distance between the closest corners of the instance and another `Rect`."""

        # We want to calculate the distance between the closest pair of corners from each `Rect`. To do so, we need to
        #  determine how the two are oriented relative to each other.
        r2_left_of_r1 = other.x2 < self.x
        r2_right_of_r1 = self.x2 < other.x
        r2_above_r1 = other.y2 < self.y
        r2_below_r1 = self.y2 < other.y

        # Closest corners: r2's top-right and r1's bottom-left
        if r2_below_r1 and r2_left_of_r1:
            return self.l_bot.distance_to_point(other.r_top)

        # Closest corners: r2's bottom-right and r1's top-left
        elif r2_left_of_r1 and r2_above_r1:
            return self.l_top.distance_to_point(other.r_bot)

        # Closest corners: r2's bottom-left and r1's top-right
        elif r2_above_r1 and r2_right_of_r1:
            return self.r_top.distance_to_point(other.l_bot)

        # Closest corners: r2's top-left and r1's bottom-right
        elif r2_right_of_r1 and r2_below_r1:
            return self.r_bot.distance_to_point(other.l_top)

        # Closest sides: r2's right and r1's left
        elif r2_left_of_r1:
            return self.x - other.x2

        # Closest sides: r2's left and r1's right
        elif r2_right_of_r1:
            return other.x - self.x2

        # Closest sides: r2's bottom and r1's top
        elif r2_above_r1:
            return self.y - other.y2

        # Closest sides: r2's top and r1's bottom
        elif r2_below_r1:
            return other.y - self.y2

        # No distance if the `Rect`s intersect
        return 0.0

    def grow_until_collision(
        self,
        others: List["Rect"],
        direction: str,
        image_height: int = None,
        image_width: int = None,
    ) -> "Rect":
        """
        Grow a `Rect` until it collides with another.

        Args:
            others:         Upon collision with any of these `Rect` instances, growing will stop.
            direction:      The direction to grow in (one of "UP", "DOWN", "LEFT", "RIGHT").
            image_height:   The height of the original document. Required when `direction` is "DOWN".
            image_width:    The width fo the original document. Required when `direction` is "RIGHT".

        Returns:
            The maximally grown `Rect`.
        """

        if any(self.is_AABB_colliding(other) for other in others):
            return self.copy()

        # Since we're going to use binary search to numerically determine to boundary between collision/no-collision, we
        #  first pick a probing value for how much we can grow the `Rect` by before there's a collision.
        direction = direction.upper()
        if direction == "UP":
            upper_bound = self.y
        elif direction == "DOWN":
            if image_height is None:
                raise ValueError("Must specify `image_height` when growing DOWN.")
            upper_bound = image_height - self.y2
        elif direction == "LEFT":
            upper_bound = self.x
        elif direction == "RIGHT":
            if image_width is None:
                raise ValueError("Must specify `image_width` when growing RIGHT.")
            upper_bound = image_width - self.x2
        else:
            raise ValueError(
                "Unrecognized direction for `Rect` growing: {}".format(direction)
            )

        # Continually refine the amount to grow the `Rect` by using binary search until
        #  we reach a final value without collision
        lower_bound = 0
        while True:
            # Determine a central value to test whether growing the `Rect` by that amount results in a collision
            # - If there's a collision, consider the lower half-range; otherwise consider the upper half-range
            pivot = (upper_bound + lower_bound) // 2

            # To test for collision, we grow the `Rect` by the `pivot` amount in the direction
            pivot_rect = self.grow(length=pivot, direction=direction)

            # If we've narrowed down the possible range to one or two values, exit the search
            if (upper_bound - lower_bound) < 2:
                break

            # If there's a collision, we call `pivot` our new upper bound and we test the lower half-range
            if any(pivot_rect.is_AABB_colliding(other) for other in others):
                upper_bound = pivot

            # Otherwise, `pivot` becomes our new lower bound and we test the upper half-range
            else:
                lower_bound = pivot

        return pivot_rect

    def find_adjacent(
        self,
        others: List["Rect"],
        direction: str,
        image_height: int = None,
        image_width: int = None,
        cond: Callable[["Rect", "Rect"], bool] = lambda a, b: True,
    ) -> List["Rect"]:
        """
        Identify `Rect` instances from a given list that the instance overlaps with in a given direction. In other
        words, identifies all other `Rect` instances that the instance would collide with if maximally grown in the
        given direction.

        Args:
            others:         The other `Rect` instances to consider for adjacency.
            direction:      The direction to search for adjacency in.
            image_height:   The height of the original document. Required when `direction` is "DOWN".
            image_width:    The width of the original document. Required when `direction` is "RIGHT".
            cond:           A comparison callable to filter out `Rect` instances identified as adjacent.
                            cond(self, other) -> False means `other` is not returned even if adjacent.

        Returns:
            The subset of `others` that are adjacent to the `Rect`, as a list.
        """
        maximal_rect = self.grow_until_collision(
            others, direction, image_height, image_width
        )

        # Based on the direction, extend the rect by a pixel to introduce collisions.
        direction = direction.upper()
        if direction == "UP":
            maximal_rect.y -= 1
            maximal_rect.h += 1
        elif direction == "DOWN":
            maximal_rect.h += 1
        elif direction == "LEFT":
            maximal_rect.x -= 1
            maximal_rect.w += 1
        elif direction == "RIGHT":
            maximal_rect.w += 1
        else:
            raise ValueError(
                "Unrecognized direction for `Rect` growing: {}".format(direction)
            )

        return [
            other
            for other in others
            if maximal_rect.is_AABB_colliding(other) and cond(self, other)
        ]

    def merge_adjacent(
        self,
        others: List["Rect"],
        direction: str,
        image_height: int = None,
        image_width: int = None,
        cond: Callable[["Rect", "Rect"], bool] = lambda a, b: True,
    ) -> Tuple["Rect", List["Rect"]]:
        """
        Merge any adjacent `Rect` instances into the instance in the given direction.

        Args:
            others:         The other `Rect` instances to consider for adjacency.
            direction:      The direction to search for adjacency in.
            image_height:   The height of the original document. Required when `direction` is "DOWN".
            image_width:    The width of the original document. Required when `direction` is "RIGHT".
            cond:           A comparison callable to filter out `Rect` instances identified as adjacent.
                            cond(self, other) -> False means `other` is not returned even if adjacent.

        Returns:
            The merged `Rect`, and a list of unmerged `Rect` instances.
        """
        adjacent_rects = self.find_adjacent(
            others, direction, image_height, image_width, cond=cond
        )
        direction = direction.upper()
        if direction == "UP":
            adjacent_rects = [r for r in adjacent_rects if r.center.y <= self.center.y]
        elif direction == "DOWN":
            adjacent_rects = [r for r in adjacent_rects if r.center.y >= self.center.y]
        elif direction == "LEFT":
            adjacent_rects = [r for r in adjacent_rects if r.center.x <= self.center.x]
        elif direction == "RIGHT":
            adjacent_rects = [r for r in adjacent_rects if r.center.x >= self.center.x]
        else:
            raise ValueError(
                "Unrecognized direction for `Rect` growing: {}".format(direction)
            )

        merged = self.merge_with(adjacent_rects)
        child_ids = {r.id_ for r in merged.children}
        others = [other for other in others if other.id_ not in child_ids]
        return merged, others

    # noinspection PyPep8Naming
    def is_AABB_colliding(self, other: "Rect") -> bool:
        """Determine whether the instance "collides" or overlaps with another `Rect`."""

        # No horizontal collision if one box starts after the other ends.
        if self.x >= other.x2:
            return False
        if self.x2 <= other.x:
            return False

        # No vertical collision if one box starts after the other ends.
        if self.y >= other.y2:
            return False
        if self.y2 <= other.y:
            return False

        return True

    def merge_with(self, rects: List["Rect"]) -> "Rect":
        """Merge multiple `Rect` instances into the instance to create a new box that contains all of them."""
        x, y, x2, y2 = int(self.x), int(self.y), int(self.x2), int(self.y2)

        # make a list to avoid iterating over points
        if not isinstance(rects, list):
            rects = [rects]

        for rect in rects:
            x = min(x, rect.x)
            y = min(y, rect.y)
            x2 = max(x2, rect.x2)
            y2 = max(y2, rect.y2)
        return Rect(x=x, y=y, w=(x2 - x), h=(y2 - y), children=[self] + rects)

    def apply(self, image: "Image.Image") -> "Image.Image":
        """Given the source Image, produce a snippet corresponding to the instance's bounding box."""
        return image.crop(box=(self.x, self.y, self.x2, self.y2))

    def corners_belong_to_edge(self, c1: Point, c2: Point) -> bool:
        """Determine whether a pair of corner points match any of the Rect's edges."""
        for edge in self.iter_edges():
            if (c1, c2) == edge or (c2, c1) == edge:
                return True
        return False

    def contains_point(self, point: Point) -> bool:
        """
        Determine whether a Point exists within the bounds of the Rect.
         ______
        |    . |
        |______|
        """
        return (
            self.l_top.x <= point.x <= self.r_top.x
            and self.l_top.y <= point.y <= self.l_bot.y
        )

    def compute_IoA(self, other: "Rect", axis: Optional[str] = None) -> float:
        """
        Computes intersection-over-area metric between two rectangles.
        IMPORTANT: IoA is not a symmetric metric IoA(a,b) ≠ IoA(b,a)
        Args:
            other: Object with which IOA is computed
            axis: x, y, None; in case IoA is computed on a box projection
        Returns:
            A(a⋃b) /  A(a)
        """
        if axis is None:
            area = self.a
        elif axis == "y":
            area = self.h
        elif axis == "x":
            area = self.w
        else:
            raise Exception(f"Axis argument should be in [None, x, y], but got: {axis}")

        return self.compute_intersection(other=other, axis=axis) / area

    def make_enclosing_rect(self, other: "Rect") -> "Rect":
        """TODO: add docstring"""

        return Rect(
            x=min(self.x, other.x),
            y=min(self.y, other.y),
            h=max(self.y2, other.y2) - min(self.y, other.y),
            w=max(self.x2, other.x2) - min(self.x, other.x),
        )

    def compute_IoU(self, other: "Rect", axis: Optional[str] = None) -> float:
        """
        Compute intersection-over-union metric between two rectangles
        Args:
            other: rectangle with which IoU is computed
            axis: x, y, or None; in case IoU is computed for box projections
        Returns:
            A(a⋃b) /  A(a⋂b)
        """
        return self.compute_intersection(other=other, axis=axis) / self.compute_union(
            other=other, axis=axis
        )

    def compute_union(self, other: "Rect", axis: Optional[str] = None) -> float:
        """
        Computes joined area of two rectangles
        Args:
            other: box with which union is computed
            axis: x, y, None; in case union of projections is computed
        Returns:
            A(a) + A(b) - A(a∩b)
        """

        if axis is None:
            self_area = self.a
            other_area = other.a
        elif axis == "y":
            self_area = self.h
            other_area = other.h
        elif axis == "x":
            self_area = self.w
            other_area = other.w
        else:
            raise Exception(f"Axis argument should be in [None, x, y], but got: {axis}")

        return (
            self_area + other_area - self.compute_intersection(other=other, axis=axis)
        )

    def compute_intersection(self, other: "Rect", axis: Optional[str] = None) -> float:
        """
        Computes intersection area with other instance of Rect class
        Args:
            other: Box to compare intersection with
            axis: Specifies axis for computing the intersection

        Returns:
            Intersection area in pixels
        """
        intersection_x = max(0, min(self.x2, other.x2) - max(self.x, other.x))
        intersection_y = max(0, min(self.y2, other.y2) - max(self.y, other.y))

        if axis == "x":
            return intersection_x
        elif axis == "y":
            return intersection_y
        else:
            return intersection_x * intersection_y

    def overlaps_with(self, other: "Rect", axis: Optional[str] = None) -> bool:
        """
        Determine whether there's an overlap with another Rect.
         ______
        |     _|____        `axis` = None
        |____|      |
             |______|

         ______
        |      |            `axis` = 'x'
        |______|
           ______
          |      |
          |______|

         ______
        |      |   ______   `axis` = 'y'
        |______|  |      |
                 |______|

        Args:
            other:  The Rect to identify an overlap with.
            axis:   The axis to look for an overlap in. Possible values:
                        None -- Look for an overlap in all axes.
                        'x'  -- Look for an overlap in the x-axis.
                        'y'  -- Look for an overlap in the y-axis.
        """
        return self.compute_intersection(other, axis=axis) > 0

    def align_with_top_edge_of(self, other: "Rect", inplace: bool = False) -> "Rect":
        """
        Line up the Rect's top edge with another.
         ______                ____ ______
        |     _|____          |    |      |
        |____|      |   -->   |____|______|
             |______|
        """
        if inplace:
            self.y = int(other.y)
            return self
        return self.copy(y=int(other.y))

    def align_with_left_edge_of(self, other: "Rect", inplace: bool = False) -> "Rect":
        """
        Line up the Rect's left edge with another.
         ______                ______
        |     _|____          |______|
        |____|      |   -->   |      |
             |______|         |______|
        """
        if inplace:
            self.x = int(other.x)
            return self
        return self.copy(x=int(other.x))

    def is_totally_after(self, other: "Rect") -> bool:
        """Check if current box is after than other box"""
        if self.y > (other.y2):
            return True
        return False

    @staticmethod
    def group_by_cond(
        rects: List["Rect"], cond: Callable[["Rect", "Rect"], bool]
    ) -> List[List["Rect"]]:
        # TODO: Format and comment
        index = list(range(len(rects)))
        groups = []
        while index:
            group = [index.pop(0)]
            if len(index) < 1:
                groups.append(group)
                break
            while True:
                new_member_indices = [
                    i
                    for i, rect in enumerate(index)
                    if any([cond(rects[rect], rects[member]) for member in group])
                ]
                for i in new_member_indices:
                    group.append(index[i])
                index = [j for i, j in enumerate(index) if i not in new_member_indices]
                if not new_member_indices:
                    groups.append(group)
                    break
        return [[rects[i] for i in group] for group in groups]


# Finds angle using cos law
def angle(a: float, b: float, c: float) -> float:
    """Given the lengths of the sides of a triangle, calculate the angle using the cosine law."""
    divid = a**2 + b**2 - c**2
    divis = 2 * a * b
    if divis > 0:
        result = float(divid) / divis
        if 1.0 >= result >= -1.0:
            return math.acos(result)
    return 0.0
