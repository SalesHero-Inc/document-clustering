from typing import Iterator
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

import cv2
import numpy as np

from sidekick.textbox import Rect
from sidekick.textbox.processing import findContours


def perform_simple_box_detection(image_arr: np.ndarray,
                                 variation: Literal[0, 1] = 0,
                                 min_area: int = 500,
                                 min_height: int = 30,
                                 x_offset: int = -5,
                                 y_offset: int = 1,
                                 ) -> Iterator[Rect]:
    """Detect bounding boxes of an image using thresholding and return boxes and the original image."""
    if image_arr.ndim != 2:
        if image_arr.shape[-1] == 3:
            image_arr = cv2.cvtColor(image_arr, cv2.COLOR_BGR2GRAY)
        elif image_arr.shape[-1] != 1:
            raise ValueError(f"Invalid image of shape: {image_arr.shape}, image must be either grayscale or RGB")

    ret, thresh1 = cv2.threshold(image_arr, 0, 255, cv2.THRESH_OTSU | cv2.THRESH_BINARY_INV)

    # Single box typically contains single word
    if variation == 0:
        rect_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (13, 7))
        dilation = cv2.dilate(thresh1, rect_kernel, iterations=1)

        rect_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 1))
        dilation = cv2.dilate(dilation, rect_kernel, iterations=1)

    # Single box may contain multiple words
    elif variation == 1:
        rect_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (27, 7))
        dilation = cv2.dilate(thresh1, rect_kernel, iterations=1)

        rect_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 1))
        dilation = cv2.dilate(dilation, rect_kernel, iterations=5)

    else:
        raise ValueError(f"Unsupported value for `variation`: {variation}")

    for cnt in findContours(dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]:
        x, y, w, h = cv2.boundingRect(cnt)

        if w * h < min_area or (h > w and h > min_height):
            continue

        x -= x_offset
        w += 2 * x_offset
        y -= y_offset
        h += 2 * y_offset

        yield Rect(x=x, y=y, w=w, h=h)
