from typing import Iterator, Union

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

import numpy as np

from sidekick.textbox import Rect
from sidekick.textbox.detection.blurring import perform_blurring_box_detection
from sidekick.textbox.detection.config import BlurringConfig, RobustConfig, SimpleConfig
from sidekick.textbox.detection.simple import perform_simple_box_detection


def detect_bounding_boxes(image_arr: np.array,
                          config: Union[BlurringConfig, SimpleConfig, RobustConfig]
                          ) -> Iterator[Rect]:
    """
    Detect bounding boxes for content in an image array.
    Returns a list of (x, y, x2, y2) boxes and the preprocessed image.
    """
    if isinstance(config, SimpleConfig):
        return perform_simple_box_detection(image_arr, **config.asdict())

    elif isinstance(config, RobustConfig):
        from sidekick.textbox.detection.robust import perform_robust_box_detection
        return perform_robust_box_detection(image_arr, **config.asdict())

    elif isinstance(config, BlurringConfig):
        return perform_blurring_box_detection(image_arr, **config.asdict())
