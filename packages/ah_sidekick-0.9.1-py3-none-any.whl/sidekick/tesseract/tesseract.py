from copy import deepcopy
from logging import getLogger
from tempfile import NamedTemporaryFile
from typing import Callable, Dict, Generator, List, Optional, Tuple, Union

import cv2
import numpy as np
from ocrmypdf import leptonica
from PIL import Image
from sidekick.textbox import Rect
from sidekick.textbox.processing import binarize, find_contours, invert_image
from tesserocr import (OEM, PSM, RIL, PyTessBaseAPI, get_languages, iterate_level)

log = getLogger(__name__)


class Tesseract(object):
    """An interface for OCR-ing Documents using Tesseract."""
    PSM = PSM
    RIL = RIL
    OEM = OEM

    def __init__(
        self,
        lang: str = 'eng',
        psm=PSM.SINGLE_BLOCK,
        oem=OEM.LSTM_ONLY,
        tessdata_path=None,
        **kwargs
    ) -> None:
        """Initialize the Tesseract engine. Keyword arguments are set as Tesseract variables."""
        if tessdata_path:
            check_available_languages(tessdata_path)
            self.api = PyTessBaseAPI(lang=lang, path=tessdata_path, psm=psm, oem=oem)
        else:
            self.api = PyTessBaseAPI(lang=lang, psm=psm, oem=oem)
        # Set Tesseract variables passed in as keyword arguments
        # NOTE: Disabling `tessedit_do_invert` provides a minor but noticeable improvement to OCR speed
        self.set_variables(tessedit_do_invert=False, **kwargs)

        log.info(
            f"Loaded API with version {self.api.Version()} and languages {self.api.GetLoadedLanguages()}"
        )

    def __del__(self):
        """Spin down the Tesseract engine on deletion."""
        if hasattr(self, 'api'):
            self.api.End()

    def set_variables(self, **kwargs) -> None:
        """Set Tesseract variables."""
        for variable, value in kwargs.items():
            if isinstance(value, bool):
                value = '1' if value else '0'
            self.api.SetVariable(variable, str(value))

    def image_to_text(
        self,
        image: Union[Image.Image, np.array],
        page_segmentation_mode: int = PSM.SINGLE_BLOCK
    ) -> Tuple[str, float]:
        """OCR the image and return extracted text."""
        self.api.SetPageSegMode(page_segmentation_mode)
        self.api.SetImage(to_pil(image))
        return self.api.GetUTF8Text(), self.api.MeanTextConf() / 100.

    def _image_to_boxes(
        self,
        image: Union[np.array, Image.Image],
        page_segmentation_mode: PSM = PSM.SINGLE_BLOCK,
        level: RIL = RIL.BLOCK,
        coordinate_units: str = 'px'
    ) -> Generator[Rect, None, None]:
        """Extract bounding boxes for text within an image."""
        image = to_pil(image)

        self.api.SetPageSegMode(page_segmentation_mode)
        self.api.SetImage(image)
        self.api.Recognize()

        ri = self.api.GetIterator()

        for r in iterate_level(ri, level):
            box = r.BoundingBox(level)
            if box is not None:
                x, y, x2, y2 = box[0], box[1], box[2], box[3]
                w, h = x2 - x, y2 - y
                if coordinate_units in ('%', 'percent'):
                    x *= 100 / image.width
                    w *= 100 / image.width
                    y *= 100 / image.height
                    h *= 100 / image.height

                text = r.GetUTF8Text(level)
                text = '' if str(text) in {' ', '|', 'nan'} else text.strip()
                score = r.Confidence(level)
                if text == '' or score == 0:
                    continue

                yield Rect(
                    x=x,
                    y=y,
                    w=w,
                    h=h,
                    text=text,
                    payload={'tesseract_confidence': score},
                )

    def image_to_boxes(
        self,
        image: Image.Image,
        page_segmentation_mode: PSM = PSM.SINGLE_BLOCK,
        level: RIL = RIL.BLOCK,
        coordinate_units: str = 'px',
        is_white_text: bool = False,
        preprocess_fn: Callable = lambda x: x
    ) -> Generator[Rect, None, None]:
        """OCR the image and return extracted boxes and text.
        Args:
            image (Union[np.array, Image.Image]): Input image.
            page_segmentation_mode (PSM, optional): Page segmentation mode.It depends on the document type.
            If it is an email, use 4 or for more complex documents, use 11 or 3. Look at https://tesseract-ocr.github.io/tessdoc/ImproveQuality.html#page-segmentation-method
            Defaults to PSM.SINGLE_BLOCK.
            level (RIL, optional): Recognition level. Defaults to RIL.BLOCK.
            coordinate_units (str, optional): Coordinate units. Defaults to 'px'.
            is_white_text (bool, optional): Whether the text is white or black. Defaults to False.

        Yields:
            Rect: A bounding box for each word.
        """

        if is_white_text:
            inverted_image = binarize(invert_image((image)))
            inverted_res = self._image_to_boxes(
                inverted_image, page_segmentation_mode, level, coordinate_units
            )

            image = binarize(preprocess_fn(image))
            orginal_res = self._image_to_boxes(
                image, page_segmentation_mode, level, coordinate_units
            )

            return resolve(orginal_res, inverted_res)

        image = binarize(preprocess_fn(image))
        return self._image_to_boxes(
            image, page_segmentation_mode, level, coordinate_units
        )


def check_available_languages(tessdata_dir):
    folder, languages = get_languages(tessdata_dir)
    if not languages:
        log.warning(f'No languages are configured at {tessdata_dir}')
    else:
        log.debug(f'The following languages are available at {tessdata_dir}:')
        for language in languages:
            log.debug(f'\t- {language}')


def to_pil(image: Union[Image.Image, np.array]) -> Image.Image:
    """Ensure that we're working with a luminance-mode Image."""
    if not isinstance(image, Image.Image):
        image = Image.fromarray(image)
    return image.convert('L')


def reorient(
    image: Union[Image.Image, np.array],
    center: Optional[Tuple[float, float]] = None,
    scale: float = 1.0,
    page_segmentation_mode: int = PSM.OSD_ONLY,
    orientation_conf_cutoff: float = 0.05
) -> np.array:
    """Fix major image orientation issues (i.e. images rotated by 90°, 180°, 270°)."""

    image = to_pil(image)
    with PyTessBaseAPI(lang='osd', psm=page_segmentation_mode) as api:
        api.SetImage(image)
        orientation_info = api.DetectOrientationScript()

    image_arr = np.array(image)
    if orientation_info and orientation_info[
        'orient_conf'] > orientation_conf_cutoff and orientation_info['orient_deg']:
        log.debug(
            f"Detected an orientation of {orientation_info['orient_deg']}° - correcting orientation..."
        )
        dim = max(image_arr.shape)
        if center is None:
            center = (dim / 2, dim / 2)

        rotation_matrix = cv2.getRotationMatrix2D(
            center, orientation_info['orient_deg'], scale
        )
        rotated_image = cv2.warpAffine(image_arr, rotation_matrix, (dim, dim))

        contours, _ = find_contours(
            rotated_image, mode=cv2.RETR_EXTERNAL, method=cv2.CHAIN_APPROX_SIMPLE
        )
        x, y, w, h = cv2.boundingRect(max(contours, key=cv2.contourArea))
        return rotated_image[y:y + h, x:x + w]

    return image_arr


def deskew(image: Union[Image.Image, np.array]) -> Image.Image:
    """Fix minor image orientation issues (i.e. images rotated by <45°)."""
    if isinstance(image, Image.Image):
        pix = leptonica.Pix.frompil(image)
    else:
        with NamedTemporaryFile(suffix='.png') as temp:
            cv2.imwrite(temp.name, image)
            pix = leptonica.Pix.open(temp.name)
    skew, conf = pix.find_skew()
    if skew:
        log.debug(f"Detected a skew of {skew}° - correcting skew...")
    return pix.deskew().topil()


def resolve(
    reference: Generator[Rect, None, None], alternative: Generator[Rect, None, None]
) -> Generator[Rect, None, None]:

    def geo_mean(box_list: List[Rect]) -> float:
        if box_list:
            arr = np.array([x.confidence for x in box_list])
            return arr.prod()**(1.0 / len(arr))
        return 0.0

    """Combine results from two images engines."""
    # Create box_list
    ref_box_list = sorted([box for box in reference], key=lambda x: (x.y, x.x))
    alt_box_list = sorted([box for box in alternative], key=lambda x: (x.y, x.x))
    offset = len(ref_box_list)
    all_nodes = {i: [] for i in range(len(ref_box_list))}
    all_nodes.update({offset + i: [] for i in range(len(alt_box_list))})
    start = 0
    # Create edges
    for i, ref_box in enumerate(ref_box_list):
        for j, alt_box in enumerate(alt_box_list[start:], start=start):
            if ref_box.is_totally_after(alt_box):
                start = j
            if alt_box.is_totally_after(ref_box):
                break
            if ref_box.overlaps_with(alt_box):
                all_nodes[i].append(offset + j)
                all_nodes[offset + j].append(i)

    graph = merge_graphs_bfs(all_nodes=all_nodes)

    for item, value in graph.items():
        group = value + [item]
        left_group = [box for box in group if box < offset]
        right_group = [box - offset for box in group if box >= offset]
        left_conf = geo_mean([ref_box_list[i] for i in left_group])
        right_conf = geo_mean([alt_box_list[i] for i in right_group])
        if left_conf > right_conf:
            for i in left_group:
                yield ref_box_list[i]
        else:
            for i in right_group:
                yield alt_box_list[i]


def merge_graphs_bfs(all_nodes: Dict[int, List[int]]) -> Dict[int, List[int]]:
    """
    Merge nodes in the graph using BFS.
    """
    visited = set()
    merged_graph = {}
    for idx, child_list in all_nodes.items():
        if idx in visited:
            continue
        merged_graph[idx] = list()
        visited.add(idx)
        queue = child_list
        while (queue):
            child = queue.pop(0)
            if child not in visited:
                merged_graph[idx].append(child)
                visited.add(child)
                queue.extend(all_nodes[child])
    return merged_graph
