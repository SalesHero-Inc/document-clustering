import time
from copy import deepcopy
from itertools import combinations
from logging import getLogger
from typing import Callable, Iterator, List

try:
    import networkx as nx
except ModuleNotFoundError as e:
    raise ModuleNotFoundError(
        str(e) + "Did you install Sidekick with the `textbox-robust` extras specified?"
    )

import numpy as np

from sidekick.textbox.detection.robust.blob_detection import detect_blobs
from sidekick.textbox.rect import Rect

log = getLogger(__name__)


def perform_robust_box_detection(image_arr: np.array,
                                 max_margin: int = 10,
                                 min_width: int = 10,
                                 max_width: int = 10,
                                 min_height: int = 10,
                                 max_iter: int = 100,
                                 horizontal_smudge_value: int = 4,
                                 vertical_smudge_value: int = 3,
                                 ) -> Iterator[Rect]:
    """
    Detect bounding boxes in an image using blob detection.

    Args:
        image_arr:                  The image to detect boxes in.
        max_margin:                 If boxes are within this margin of each other, they get merged.
        min_width:                  The minimum width of a valid textbox (smaller boxes are discarded).
        max_width:                  The maximum width of a valid textbox (larger boxes are discarded).
        min_height:                 The minimum height of a valid textbox (smaller boxes are discarded).
        max_iter:                   The maximum number of iterations to try and merge textboxes until they converge.
        horizontal_smudge_value:    The factor by which to smudge content horizontally when detecting blobs. Higher
                                     values result in more horizontally aggregated boxes.
        vertical_smudge_value:      The factor by which to smudge content vertically when detecting blobs. Higher values
                                     result in more vertically aggregated boxes.

    Yields:
        `sidekick.textbox.Rect` instances of detected boxes.
    """

    boxes = list(detect_blobs(
        image_arr,
        min_width=min_width,
        min_height=min_height,
        horizontal_smudge_value=horizontal_smudge_value,
        vertical_smudge_value=vertical_smudge_value
    ))

    previous_iter = None
    success = False
    log.debug('Iteratively merging boxes')

    t0 = time.time()
    for n in range(max_iter):
        # Merge overlapping boxes
        boxes = merge_boxes_if(
            condition=lambda box_a, box_b: box_a.overlaps_with(box_b),
            boxes=boxes,
            max_iter=max_iter
        )

        # Merge boxes that are inline and at most X pixels away from each other
        # NOTE: This handles some cases where letters within a word get separate boxes and need to be merged
        boxes = merge_boxes_if(
            condition=are_rectangles_inline,
            boxes=boxes,
            max_iter=max_iter,
            max_margin=max_margin,
            max_width=max_width
        )

        signature = hash(tuple(boxes))
        if signature == previous_iter:
            success = True
            break
        previous_iter = signature

    if success:
        log.debug(f"Converged after {n} iterations ({time.time() - t0} seconds). ({len(boxes)} identified")
    else:
        log.debug(f"Failed to converge after {time.time() - t0} seconds. ({len(boxes)} identified)")

    return boxes


def merge_boxes_if(condition: Callable[[Rect, Rect], bool],
                   boxes: List[Rect],
                   max_iter: int,
                   *args,
                   **kwargs
                   ) -> List[Rect]:
    """Merge boxes if a pair of them meet a given condition. Args and kwargs are passed through to `condition`."""
    boxes = deepcopy(boxes)
    log.debug(f"Merging overlapping boxes - current count: {len(boxes)}")

    # NOTE: Since a merged box can include concave regions of its subset, we need to process this iteratively
    for n in range(max_iter):
        n_boxes = len(boxes)
        log.debug(f"Iteration {n+1}: {n_boxes} boxes")

        adj = np.zeros((n_boxes, n_boxes), dtype=np.bool)
        for i, j in combinations(np.arange(n_boxes), r=2):
            adj[i, j] = adj[j, i] = condition(boxes[i], boxes[j], *args, **kwargs)

        if not adj.any():
            log.debug('Converged.')
            break

        boxes = list(merge_adjacent_boxes(boxes, adj))

    return boxes


def merge_adjacent_boxes(boxes: List[Rect], adj: np.ndarray) -> Iterator[Rect]:
    """Merge adjacent boxes into a maximal bounding Rect."""
    assert adj.ndim == 2 and adj.shape[0] == adj.shape[1], 'Adjacency matrix needs to be square.'
    G = nx.convert_matrix.from_numpy_matrix(adj, parallel_edges=False, create_using=nx.Graph)

    # Iterate over groups of adjacent boxes
    for group in nx.algorithms.components.connected_components(G):
        group_boxes = [boxes[idx] for idx in group]

        # Starting with the first boxes coordinates, find the coordinates that contain all group boxes
        x, y, x2, y2 = [getattr(group_boxes[0], coord) for coord in ('x', 'y', 'x2', 'y2')]
        for box in group_boxes:
            x = min(x, box.x)
            y = min(y, box.y)
            x2 = max(x2, box.x2)
            y2 = max(y2, box.y2)

        yield Rect(x=x, y=y, w=x2-x, h=y2-y)


def are_rectangles_inline(a: Rect,
                          b: Rect,
                          max_margin: int,
                          max_width: int = 10,
                          ) -> bool:
    """If two boxes are inline within max_margin, let's merge them."""
    smaller_box_height, bigger_box_height = sorted([a.h, b.h])
    combined_box_height = max(a.y2, b.y2) - min(a.y, b.y)
    combined_box_width = max(a.x2, b.x2) - min(a.x, b.x)

    # the boxes are considered inline if the smaller one overlaps 50% or more on y-axis with the bigger box
    inline = (smaller_box_height * 0.5) >= (combined_box_height - bigger_box_height)

    if a.overlaps_with(b, axis='x'):
        separation = -1
    else:
        separation = max(a.x, b.x) - min(a.x2, b.x2)

    if inline and (separation < max_margin) and (combined_box_width <= max_width):
        return True
    return False
