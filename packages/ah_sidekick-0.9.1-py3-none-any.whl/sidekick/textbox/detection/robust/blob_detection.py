from copy import deepcopy
from typing import Iterator

import cv2
import numpy as np

from sidekick.textbox import Rect
from sidekick.textbox.processing import findContours


def get_edges(gray):
    """Detect edges using Scharr method"""
    schar_x = cv2.Scharr(gray, cv2.CV_64F, 1, 0)
    schar_y = cv2.Scharr(gray, cv2.CV_64F, 0, 1)
    edges = np.hypot(schar_x, schar_y)
    edges *= 255.0 / np.max(edges)

    return edges.astype(np.uint8)


def contours_to_rect(contours,
                     img_boxes,
                     min_height,
                     min_width,
                     max_ratio=0.5,
                     max_HW_ratio=2,
                     min_HW_ratio=0.2,
                     ) -> Iterator[Rect]:
    """
    Given contours return boxes spanning them
    `max_ratio` referes to ratio of bbox size to entire image
    variable bboxes is an image with bboxes projected onto it
    """
    patch_size = img_boxes.shape[0] * img_boxes.shape[1]
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)

        if h / w > max_HW_ratio and w > 15:
            continue

        if h / w < min_HW_ratio and h < 10:
            continue

        if w * h < max_ratio * patch_size and (w > min_width and h > min_height):
            yield Rect(x=x, y=y, w=w, h=h)


def detect_blobs(img: np.array,
                 min_width: int = 10,
                 min_height: int = 10,
                 horizontal_smudge_value: int = 3,
                 vertical_smudge_value: int = 2,
                 ) -> Iterator[Rect]:
    """
    Blob detector that's used for text finding
    """
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    elif len(img.shape) < 2 or len(img.shape) > 3:
        raise ValueError(
            f"Invalid image of shape: {img.shape}, image needs to be either grayscale or rgb"
        )

    edges = get_edges(img)
    thresh = cv2.threshold(edges, 0, 255, cv2.THRESH_OTSU)[1]

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 2))
    blobs = cv2.morphologyEx(thresh, cv2.MORPH_ERODE, kernel, iterations=1)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (horizontal_smudge_value, vertical_smudge_value))
    blobs = cv2.morphologyEx(blobs, cv2.MORPH_DILATE, kernel, iterations=4)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 2))
    blobs = cv2.morphologyEx(blobs, cv2.MORPH_ERODE, kernel, iterations=1)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 1))
    blobs = cv2.morphologyEx(blobs, cv2.MORPH_ERODE, kernel, iterations=2)

    contours, _ = findContours(blobs, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    return contours_to_rect(contours, deepcopy(img), min_width=min_width, min_height=min_height)
