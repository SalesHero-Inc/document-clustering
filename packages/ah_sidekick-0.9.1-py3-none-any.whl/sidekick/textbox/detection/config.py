try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

from dataclasses import asdict, dataclass


class _Config:
    """A configuration for textbox detection."""

    def asdict(self):
        return asdict(self)


@dataclass(frozen=True)
class BlurringConfig(_Config):
    x_smoothing: int = 21
    y_smoothing: int = 7
    min_area: int = 1000


@dataclass(frozen=True)
class RobustConfig(_Config):
    max_margin: int = 10
    min_width: int = 10
    max_width: int = 10
    min_height: int = 10
    horizontal_smudge_value: int = 4
    vertical_smudge_value: int = 3
    max_iter: int = 100


@dataclass(frozen=True)
class SimpleConfig(_Config):
    variation: Literal[0, 1] = 1
    min_area: int = 500
    min_height: int = 30
    x_offset: int = -5
    y_offset: int = 1
