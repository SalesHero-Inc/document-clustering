from copy import deepcopy
from typing import List, Optional, Tuple, Union

try:
    import cv2
    import numpy as np
    from PIL import Image, ImageEnhance

except ImportError as e:
    raise ImportError(
        "Dependencies for textbox extraction were not installed. "
        "Did you remember to `pip install sidekick[textbox]`?"
    ) from e

MAX_VALUE = 255
READABLE_DIFF = 0.05


def enhance_contrast(image: Union[Image.Image, np.array], factor: float) -> np.array:
    """Stretch contrast"""
    if isinstance(image, np.ndarray):
        image = Image.fromarray(image, mode="L")
    else:
        image = image.convert("L")

    image = ImageEnhance.Contrast(image).enhance(factor=factor)
    # noinspection PyTypeChecker
    return np.array(image)


def trim_borders(
    image: np.array, cutoff=127
) -> Tuple[np.array, np.array, Tuple[int, int, int, int]]:
    """Remove empty white regions around the sides of the document."""
    img_copy = deepcopy(image)
    gray = 255 * (image < cutoff).astype(np.uint8)  # To invert the text to white
    gray = cv2.morphologyEx(
        gray, cv2.MORPH_OPEN, np.ones((2, 2), dtype=np.uint8), iterations=1
    )
    coords = cv2.findNonZero(gray)  # Find all non-zero points (text)
    x, y, w, h = cv2.boundingRect(coords)  # Find minimum spanning bounding box
    image = image[y : y + h, x : x + w]
    img_copy = img_copy[y : y + h, x : x + w]

    return image, img_copy, (x, y, w, h)


def find_contours(*args, **kwargs):
    """Find contours in an image using `cv2.findContours`."""

    if int(cv2.__version__[0]) >= 4 or int(cv2.__version__[0]) < 3:
        contours, hierarchy = cv2.findContours(*args, **kwargs)
    else:
        _, contours, hierarchy = cv2.findContours(*args, **kwargs)

    return contours, hierarchy


def remove_lines(image: np.ndarray) -> np.ndarray:
    """Remove horizontal and vertical lines from a grayscale image."""

    h_kernel_size = max(image.shape[0] // 2000, 1) * 25
    v_kernel_size = max(image.shape[1] // 1500, 1) * 25
    for thickness in (3, 5):
        image = filter_lines(image, kernel_size=(h_kernel_size, 1), thickness=thickness)

    for thickness in (3, 5):
        image = filter_lines(image, kernel_size=(1, v_kernel_size), thickness=thickness)

    return image


def filter_lines(
    image: np.array,
    kernel_size: Tuple[int, int] = (25, 1),
    thickness: int = 4,
    background_color: Tuple[int, int, int] = (255, 255, 255),
) -> np.array:
    """Filter horizontal or vertical lines from a given image, and return a copy without lines."""
    for contour in find_lines(image, kernel_size, return_contours=True):
        cv2.drawContours(
            image,
            contours=[contour],
            contourIdx=-1,
            color=background_color,
            thickness=thickness,
        )
    return image


def up_scale(image: np.array, size: int = 3000) -> np.array:
    """Upsize an image by a given factor."""
    factor = size / image.shape[0]
    dim = (int(image.shape[1] * factor), int(image.shape[0] * factor))
    return cv2.resize(image, dim, interpolation=cv2.INTER_AREA)


def find_lines(
    image: np.array,
    kernel_size: Tuple[int, int] = (25, 1),
    threshold: int = 128,
    return_contours: bool = False,
) -> List[List[int]]:
    """Use CV2 morphological operators to identify horizontal or vertical lines in an image."""
    _, thresh = cv2.threshold(
        deepcopy(image), threshold, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
    )
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, kernel_size)
    detected_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)
    contours, _ = find_contours(
        detected_lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )

    if return_contours:
        return contours
    return sorted(
        [cv2.boundingRect(contour) for contour in contours], key=lambda b: b[1]
    )


def sobel_edge_detector(img: np.ndarray) -> np.ndarray:
    grad_x = cv2.Sobel(img, cv2.CV_64F, 1, 0)
    grad_y = cv2.Sobel(img, cv2.CV_64F, 0, 1)
    grad = np.sqrt(grad_x**2 + grad_y**2)
    grad_norm = (grad * 255 / grad.max()).astype(np.uint8)
    return cv2.threshold(grad_norm, 0, 255, cv2.THRESH_OTSU)[1]


def get_edges(image: np.array) -> np.array:
    """Detect edges in a grayscale image using the Scharr method."""
    schar_x = cv2.Scharr(image, cv2.CV_64F, 1, 0)
    schar_y = cv2.Scharr(image, cv2.CV_64F, 0, 1)
    edges = np.hypot(schar_x, schar_y)
    edges *= 255.0 / np.max(edges)

    edged = edges.astype(np.uint8)
    return cv2.threshold(edged, 0, 255, cv2.THRESH_OTSU)[1]


def smart_crop(
    image: np.array,
    threshold: int = 255,
    margin: int = 0,
    margin_left: Optional[int] = None,
    margin_top: Optional[int] = None,
    margin_right: Optional[int] = None,
    margin_bottom: Optional[int] = None,
):
    """
    Crop a given image to only the rectangular region containing non-white content.

    Args:
        image:          The image to crop.
        threshold:
        margin:         A single margin value (in pixels) to use for all sides. Any specific margins specified will
                         override this value for those specific sides.
        margin_left:    The margin size (in pixels) for the left side of the image.
        margin_top:     The margin size (in pixels) for the top of the image.
        margin_right:   The margin size (in pixels) for the right side of the image.
        margin_bottom:  The margin size (in pixels) for the bottom of the image.

    Returns:
        A cropped Pillow Image.
    """
    if not (len(image.shape) < 3 or image.shape[2] == 1):
        raise ValueError(
            "Image must be grayscale. Got image with shape {}. "
            "Need len(image.shape) < 3 or image.shape[2] == 1.".format(image.shape)
        )

    # If any side-margins haven't been specified, use the flat margin value instead.
    if margin_left is None:
        margin_left = int(margin)
    if margin_top is None:
        margin_top = int(margin)
    if margin_right is None:
        margin_right = int(margin)
    if margin_bottom is None:
        margin_bottom = int(margin)

    # Use extreme values for the minimum and maximum non-white X/Y values to start.
    min_x, min_y = image.shape[0] - 1, image.shape[1] - 1
    max_x, max_y = 0, 0

    # A flag to catch cases where a blank image was passed, so that cropping operations don't break.
    is_blank = True

    # Iterate through every pixel and detect whether it is a white pixel or not.
    # NOTE: Technically we're only iterating through values for the red channel, but this works fine under the
    #        valid assumption that we're only working with black and white images.
    for _x, row in enumerate(image):
        for _y, px in enumerate(row):
            # If the pixel is non-white, update our detected extrema where applicable.
            if px <= threshold:
                is_blank = False
                min_x = min(min_x, _x)
                min_y = min(min_y, _y)
                max_x = max(max_x, _x)
                max_y = max(max_y, _y)

    # Return blank images as is, without cropping.
    if is_blank:
        return image

    crop_im = image[
        max(0, min_x - margin_top) : min(image.shape[0] - 1, max_x + margin_bottom),
        max(0, min_y - margin_left) : min(image.shape[1] - 1, max_y + margin_right),
    ]
    return crop_im


def binarize(image: Image.Image, window_ratio=4, stripe_ratio=1) -> Image.Image:
    """It will binarize the image. It uses a sliding window with size dim // 4.


    Args:
        image (Image.Image): Image to Binarize.
        window_ratio (int): The divider to find the window size.
        stripe_ratio (int): The divider to find the stripe size.
    Returns:
        Image.Image: binaerized image.
    """
    image = np.array(image.convert("L"))
    image = enhance_image(image)
    height, width = image.shape
    h_window = height // window_ratio
    w_window = width // window_ratio

    binarized_img = np.ones_like(image) * 255

    h_stripe = h_window // stripe_ratio
    w_stripe = w_window // stripe_ratio
    if (h_stripe < 1) or (w_stripe < 1):
        return Image.fromarray(binarized_img)

    for h_start in range(0, height, h_stripe):
        for w_start in range(0, width, w_stripe):
            h_end = h_start + h_window
            w_end = w_start + w_window
            window = image[h_start:h_end, w_start:w_end].astype(float)
            diff = window.max() - window.min()
            if diff > MAX_VALUE * READABLE_DIFF:
                window = ((window - window.min()) / diff) * MAX_VALUE
                window = window.astype(np.uint8)
                _, window = cv2.threshold(window, 0, 255, cv2.THRESH_OTSU)
                slide_window = binarized_img[h_start:h_end, w_start:w_end]
                binarized_img[h_start:h_end, w_start:w_end] = np.min(
                    np.stack([window.astype(np.float32), slide_window], axis=2), axis=2
                )
    return Image.fromarray(binarized_img)


def enhance_image(img: np.ndarray, factor=1.0):
    """
    Denoise and enhance dark areas in the image
    Args:
        img:        np.array image - should be 3 channel
        factor:     enhancing factor used for contrast and making the dark areas even more distinctive
    Returns:
        np.array image
    """
    img = np.array(Image.fromarray(img).convert("RGB"))
    enhanced = np.ones_like(img[:, :, 0]).astype(np.int64)

    # multiply the image along the channel dimension - work on the image negative (black would be (255,255,255))
    if img.ndim > 2:
        for i in range(1, img.shape[2]):
            tmp = np.ones_like(enhanced) * 255 - img[:, :, i]
            enhanced *= tmp

        # extra enhancement
    enhanced = np.power(enhanced, factor)

    # normalize image
    enhanced = enhanced / (enhanced.max() + 1e-6)
    enhanced *= 255
    enhanced = enhanced.astype(np.uint8)

    # invert to regular scheme
    enhanced = np.ones_like(enhanced) * 255 - enhanced

    # extra contrast enhancement
    enhanced = enhance_contrast(enhanced, factor + 1)

    return enhanced


def find_document(
    img: np.ndarray, min_area_ratio: float = 0.1, max_area_ratio: float = 0.9
) -> np.ndarray:
    """
    Crop the document from the image. This is done by detecting the document's bounding box. Other parts are masked with black."""
    edged = get_edges(img)

    edged[0, :] = 1
    edged[-1, :] = 1
    edged[:, 0] = 1
    edged[:, -1] = 1
    # return binary_img, edged
    # sort contours based on area
    contour_list, _ = find_contours(edged, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    h, w = img.shape[:2]

    min_thresh_area = min_area_ratio * w * h
    max_thresh_area = max_area_ratio * w * h

    list_contours = list()
    for contour in contour_list:
        rect_page = cv2.minAreaRect(contour)
        box_page = np.int0(cv2.boxPoints(rect_page))
        area = cv2.contourArea(box_page)
        if min_thresh_area < area < max_thresh_area:
            list_contours.append(box_page)

    if not list_contours:
        return img
    biggest_contour = max(list_contours, key=cv2.contourArea)
    mask = cv2.fillPoly(
        img=img.copy(), pts=biggest_contour.reshape(1, -2, 2), color=(0, 0, 0)
    )
    masked_image = cv2.bitwise_and(img, ~mask)
    return masked_image


def resolve_shadow(image: Image.Image) -> Image.Image:
    """https://stackoverflow.com/questions/44752240/how-to-remove-shadow-from-scanned-images-using-opencv/44752405#44752405"""

    image_arr = np.array(image)
    rgb_planes = cv2.split(image_arr)

    result_planes = []
    for plane in rgb_planes:
        dilated_img = cv2.dilate(plane, np.ones((7, 7), np.uint8))
        bg_img = cv2.medianBlur(dilated_img, 21)
        diff_img = 255 - cv2.absdiff(plane, bg_img)
        norm_img = cv2.normalize(
            diff_img,
            None,
            alpha=0,
            beta=255,
            norm_type=cv2.NORM_MINMAX,
            dtype=cv2.CV_8UC1,
        )
        result_planes.append(norm_img)

    return Image.fromarray(cv2.merge(result_planes))


def invert_image(image: Image.Image) -> Image.Image:
    """Invert the image."""
    image = np.array(image.convert("L"))
    image = cv2.bitwise_not(image)
    return Image.fromarray(image)
