from sidekick.document.document import Document, FileType
from sidekick.document.comb_field import CombField