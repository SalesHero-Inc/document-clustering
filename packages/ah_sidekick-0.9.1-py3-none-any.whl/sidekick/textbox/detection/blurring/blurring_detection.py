from typing import Iterator

import cv2
import numpy as np

from sidekick.textbox import Rect
from sidekick.textbox.detection.blurring import ops
from sidekick.textbox.processing import findContours


def perform_blurring_box_detection(image_arr: np.ndarray,
                                   x_smoothing: int = 21,
                                   y_smoothing: int = 7,
                                   min_area: int = 1000,
                                   **kwargs) -> Iterator[Rect]:
    """
    Find bounding boxes for regions of content in an image array.

    Args:
        image_arr:              The image array to extract boxes from.
        x_smoothing:            The extent to smooth x-axis values before identifying continuous regions.
        y_smoothing:            The extent to smooth y-axis values before identifying continuous regions.
        min_area:               The minimum area a box needs to have to not be dropped.
        **kwargs:               Additional keyword arguments to pass to `sidekick.textbox.Rect` initialization.

    Yields:
        `sidekick.textbox.Rect` instances of content boxes.
    """
    image_arr = ops.prepare_image(image_arr)

    payload = kwargs.pop('payload', {})
    blurred_arr = ops.blur(image_arr, kernel_size=(y_smoothing or 1, x_smoothing or 1))
    for contour in findContours(blurred_arr, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]:
        x, y, w, h = cv2.boundingRect(contour)

        # Filter out small boxes
        if w*h < min_area:
            continue

        yield Rect(x, y, w, h, payload=dict(payload), **kwargs)
