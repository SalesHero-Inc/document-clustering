from typing import Optional, Tuple, Union

import cv2
import numpy as np

from sidekick.textbox.processing import filter_lines


def _get_axis(value: Union[int, str]) -> int:
    """Parse an axis value ('x' / 'y') into an integer."""
    return ['x', 'y', 0, 1].index(value) % 2


def blur(arr: np.ndarray,
         kernel_size: Optional[Tuple[int, int]] = None,
         factor: Optional[int] = None,
         axis: Union[None, int, str] = None
         ) -> np.ndarray:
    """
    Perform a Gaussian blur on an image (without diminishing pixel values).

    Args:
        arr:            The image array to blur.
        kernel_size:    The kernel to use for blurring. If `None`, `factor` must be set.
        factor:         The extent to which the specified axis/axes will be blurred.
        axis:           The axis to blur. If `None`, blur in both axes.
    Returns:
        The blurred image array.
    """
    if kernel_size is None:
        kernel_size = [factor, factor]
        if axis is not None:
            axis = _get_axis(axis)
            kernel_size[axis] = 1

    return cv2.filter2D(
        arr,
        -1,
        np.ones(kernel_size, np.float32)
    )


def prepare_image(array: np.ndarray, threshold: int = 128) -> np.ndarray:
    """Prepare an image array for extraction by inverting it, and thresholding it."""
    array = cv2.fastNlMeansDenoising(array)
    array = 255 - filter_lines(array)
    _, array = cv2.threshold(array, threshold, 255, cv2.THRESH_BINARY)
    return array
