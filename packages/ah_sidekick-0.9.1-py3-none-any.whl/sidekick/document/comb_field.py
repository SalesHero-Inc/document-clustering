from logging import getLogger
from timeit import default_timer as timer
from typing import Union

import cv2
import numpy as np
from PIL.Image import Image

logger = getLogger(__name__)


class CombField(object):
    """A class encapsulating several operations performed on document comb fields."""

    def __init__(self, image: Union[Image, np.ndarray]) -> None:
        """
        Initialize the CombField class from comb field file.
        Args:
            path: The image that contains the comb field
        Raises:
             FileNotFoundError, if the path provided does not exist
        """

        if isinstance(image, Image):
            image = np.array(image)

        if len(image.shape) == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        self.field_image = image
        self.h, self.w = self.field_image.shape

    def _remove_background(self, image: np.ndarray, sigma: int = 11) -> np.ndarray:
        """
        Divides the original image with a blurred version of it to remove the paper background that
        results from scanning the document or taking a picture in poor light conditions
        Args:
            image: image to have its background removed
            sigma: variance used when applying gaussian blur
        Returns:
            Input image with the background removed
        """
        start = timer()

        blurred = cv2.GaussianBlur(image, (0, 0), sigmaX=sigma, sigmaY=sigma)
        cleaned = cv2.divide(image, blurred, scale=255)

        end = timer()
        logger.debug(f"Background removed in {end - start:.3f}s.")

        return cleaned

    def remove_vertical_lines(self) -> np.ndarray:
        """
        Removes the vertical separator lines found typically found in comb fields.
        Returns:
            The comb field image with the separator lines removed.
        """

        # create a copy of the image as the removal process is destructive
        image = np.copy(self.field_image)

        # first remove the background that might have been created as a result of the scanning
        # process or because the image was taken with a camera
        image = self._remove_background(image, sigma=33)

        # next remove all the vertical lines that span across the height of the field
        image = self._remove_vertical_lines(
            image,
            blur_mean=3,
            edge_thresh_min=100,
            edge_thresh_max=150,
            mask_line_width=3,
            inpaint_radius=10,
        )

        # remove all the large structures from the image
        image = self._remove_large_structures(
            image, blur_mean=11, bin_threshold_value=200, surface_threshold=100
        )

        # isolate the text in the comb field image
        image = self._extract_dark_text(
            image, blur_mean=3, bin_threshold_value=240, erosion_kernel_size=5
        )

        return image

    def _remove_vertical_lines(
        self,
        image: np.ndarray,
        blur_mean: int = 3,
        edge_thresh_min: int = 100,
        edge_thresh_max: int = 150,
        mask_line_width: int = 3,
        inpaint_radius: int = 10,
        dilation_kernel_factor: float = 0.5,
    ) -> np.ndarray:
        """
        Removes vertical lines from the image using Hough Transform
        Args:
            image:                  image to have its vertical lines removed
            blur_mean:              mean value used for gaussian blur
            edge_thresh_min:        minimum threshold for the hysteresis procedure
            edge_thresh_max:        maximum threshold for the hysteresis procedure
            mask_line_width:        width with which the detected lines are painted on the pask
            inpaint_radius:         radius in pixels used for inpainting
            dilation_kernel_factor: factor by which we multiply the hight with to get the vertical
                                    size of the dilation kernel
        Returns:
            Input image with the vertical lines removed
        """
        start = timer()

        # calculate the edges for the input image
        # sometimes the vertical lines turn into dashed lines because of poor scanning
        # in that case, hough transform cannot detect them
        # for that reason, we dilate the image vertically and "connect" the dashes/dots
        dilation_kernel = np.ones((int(dilation_kernel_factor * self.h), 1), np.uint8)
        proc_img = cv2.GaussianBlur(image, (blur_mean, blur_mean), 0)
        proc_img = cv2.adaptiveThreshold(
            proc_img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 10
        )
        proc_img = cv2.dilate(proc_img, dilation_kernel, iterations=1)
        proc_img = cv2.Canny(proc_img, edge_thresh_min, edge_thresh_max, apertureSize=3)

        # find all the lines that are vertical and gave a length more than 50% of the height of
        # the image
        lines = cv2.HoughLines(
            image=proc_img,
            rho=1,
            theta=np.pi / 180,
            threshold=int(0.5 * self.h),
            min_theta=0,
            max_theta=0.01,
        )

        if lines is None:
            logger.debug(f"No lines found for file.")
            return image

        # create a mask for the lines
        inpaint_mask = np.zeros((self.h, self.w), np.uint8)
        for line in lines:
            for rho, theta in line:
                a = np.cos(theta)
                b = np.sin(theta)
                x0 = a * rho
                y0 = b * rho
                x1 = int(x0 + 1000 * (-b))
                y1 = int(y0 + 1000 * (a))
                x2 = int(x0 - 1000 * (-b))
                y2 = int(y0 - 1000 * (a))

                cv2.line(
                    inpaint_mask, (x1, y1), (x2, y2), (255, 255, 255), mask_line_width
                )

        # use in-painting to remove the line. in-painting is needed since the line might cross on
        # the characters
        image = cv2.inpaint(image, inpaint_mask, inpaint_radius, cv2.INPAINT_NS)
        end = timer()
        logger.debug(f"Lines removed from image in {end - start:.3f}s.")

        return image

    def _remove_large_structures(
        self,
        image: np.ndarray,
        blur_mean: int = 11,
        bin_threshold_value: int = 128,
        surface_threshold: int = 100,
    ) -> np.ndarray:
        """
        Removes large structures from the image by using contour detection
        Args:
            image:               image from where the large structures need to be removed
            blur_mean:           mean value used for gaussian blur
            bin_threshold_value: threshold value used for binarizing the image
        Returns:
            The input image with the large structures removed
        """
        # binarize the image
        start = timer()
        bin_image = self._binarize_image(
            image, blur_mean=blur_mean, bin_threshold_value=bin_threshold_value
        )

        # calculate the contures of the image
        contours, hierarchy = cv2.findContours(
            bin_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        mask = np.ones((self.h, self.w)) * 255

        # paint in the contours that have surface larger than the threshold
        for contour in contours:
            if cv2.contourArea(contour) > surface_threshold:
                hull = cv2.convexHull(contour)
                cv2.drawContours(mask, [hull], -1, 0, -1)

        image[mask != 0] = 255
        end = timer()
        logger.debug(f"Large structures removed from image in {end - start:.3f}s.")

        return image

    def _binarize_image(
        self, image: np.ndarray, blur_mean: int = 11, bin_threshold_value: int = 128
    ) -> np.ndarray:
        """
        Binarizes the input image
        Args:
            image:               image to be binarized
            blur_mean:           mean value used for gaussian blur
            bin_threshold_value: threshold value used for binarizing the image
        Return:
            Binarized image
        """
        proc_img = cv2.GaussianBlur(image, (blur_mean, blur_mean), 0)
        proc_img = cv2.threshold(proc_img, bin_threshold_value, 255, cv2.THRESH_BINARY)[
            1
        ]

        return proc_img

    def _extract_dark_text(
        self,
        image: np.ndarray,
        blur_mean: int = 11,
        bin_threshold_value: int = 128,
        erosion_kernel_size: int = 0,
    ) -> np.ndarray:
        """
        Isolates the dark text in the image by employing masking and binarization
        Args:
            image: image in which we want to isolate the text
            blur_mean: mean used when applying gaussian blur during binarisation
            bin_threshold_value: threshold value used for binarising the image
            erosion_kernel_size: kernel size to be used when performing the erosion step
        Returns:
            Input image masked but the binarized version of it
        """
        start = timer()

        bin_image = self._binarize_image(
            image, blur_mean=blur_mean, bin_threshold_value=bin_threshold_value
        )

        if erosion_kernel_size > 0:
            kernel = np.ones((erosion_kernel_size, erosion_kernel_size), np.uint8)
            bin_image = cv2.erode(bin_image, kernel, iterations=1)

        image[bin_image == 255] = 255

        end = timer()
        logger.debug(f"Dark text isolated in image in {end - start:.3f}s.")

        return image
