"""A class serving as an interface between Paddle and othe AH projects"""
from logging import getLogger
from typing import Union, Tuple, Generator, List
import re

import cv2
from paddleocr import PaddleOCR
from PIL import Image
import numpy as np
from sklearn.cluster import KMeans

from sidekick.textbox import Rect

log = getLogger(__name__)
SUPPORTED_LANGUAGES = ["en", "ch", "french", "german", "korean", "japan"]
SUPPORTED_COORD_UNITS = ["px", "%", "percent", "relative", "pixels", "absolute"]


class PaddleEngine:
    """
    An interface for OCR-ing Documents using PaddleOCR
    """

    def __init__(
        self,
        lang: str = "en",
        use_angle_cls: bool = False,
        rec_batch_num: int = 16,
        enable_mkldnn: bool = True,
        show_log: bool = False,
    ):
        """Initialize the Paddle engine"""
        # check if provided language is supported
        if lang not in SUPPORTED_LANGUAGES:
            raise ValueError(
                f"Language {lang} is not found in the supported languages: "
                f'{", ".join(SUPPORTED_LANGUAGES)}'
            )

        self.api = PaddleOCR(
            use_angle_cls=use_angle_cls,
            lang=lang,
            enable_mkldnn=enable_mkldnn,
            rec_batch_num=rec_batch_num,
            show_log=show_log,
        )
        self.snippet_margin_px = 5

    def image_to_text(self, image: Union[Image.Image, np.array]) -> Tuple[str, float]:
        """
        OCR the input image and reurn the extracted text.
        Args:
            image: image to be ocr-ed
        Returns:
            Tuple containing the extracted text and the confidence of the model
        """
        # silently converting image to the format expected from paddle so that the method inputs are
        # a bit more flexible
        image = self._silently_convert_input(image)

        # perform OCR on the input image
        # tried to perform recognition only but seems like paddle has an issue with recognition
        # on images containing a lot of text
        # this is most likely because the image input to the rec model is resized to be quite small
        # https://github.com/PaddlePaddle/PaddleOCR/discussions/7600
        results = self.api.ocr(image, cls=False)
        texts = [line[1][0] for line in results]
        scores = [line[1][1] for line in results]
        full_text = " ".join(texts)
        mean_score = np.mean(scores)
        return full_text, float(mean_score)

    def image_to_boxes(
        self,
        image: Union[Image.Image, np.array],
        coordinate_units: str = "px",
        refine_detection: bool = False,
    ) -> Generator[Rect, None, None]:
        """OCR the image and return extracted boxes and text.
        Args:
            image: Input image.
            coordinate_units: indicator of whether relative or absolute coordinates should be
                              returned
            refine_detection: flag to indicate if refinement postprocessing will be applied
                              on the detection results
        Yields:
            Rect: A bounding box for each word.
        """

        # validation and silent conversion to make the input to the method more flexible
        if coordinate_units not in SUPPORTED_COORD_UNITS:
            raise ValueError(
                f"Coordinate units {coordinate_units} is not found in the supported coordinate "
                f'units: {", ".join(SUPPORTED_COORD_UNITS)}'
            )
        image = self._silently_convert_input(image)

        # perform both text detection and recognition on the input image
        results = self.api.ocr(image, cls=False, det=True, rec=True)
        # paddle represents boxes with xy coords for each corner of the box we convert to xyxy here
        results = [[self._paddle_box_to_xyxy(res[0]), res[1]] for res in results]

        yield from self._process_results(
            coordinate_units, image, refine_detection, results
        )

    def _process_results(self, coordinate_units, image, refine_detection, results):
        """Recursive function that transforms results into objects of the Rect class."""
        # iterate over the results
        # first entry is a list of bounding boxes
        # second is a list of tuples containing text-score pairs
        for box, rec_res in results:
            text = rec_res[0].strip()

            # if there is a space in between words, paddle most likely has merged the bounding
            # boxes of two words
            # if detection refinement is asked to be performed, we split the merged bounding box
            # int bounding boxes of single words
            if " " in text and refine_detection:
                log.debug(
                    f"Detected a multi-token box of {len(re.split('-| ', text))} tokens."
                )
                # got some new results here so let's do the same thing all over :D
                new_results = self._split_bbox(box, image)
                yield from self._process_results(
                    coordinate_units, image, refine_detection, new_results
                )
            else:
                rect = self._make_result_rect(box, rec_res, image, coordinate_units)
                if rect is None:
                    continue
                yield rect

    def _silently_convert_input(
        self, image: Union[Image.Image, np.ndarray]
    ) -> np.ndarray:
        """Performs format transformations to match potential inputs with the format paddle expects
        the image."""
        if isinstance(image, Image.Image):
            if image.mode == 'RGBA':
                image = image.convert('RGB')
            image = np.array(image)
        # paddle works on RGB images
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)

        return image

    def _paddle_box_to_xyxy(self, box: List) -> List:
        """Transforms box coords from paddle to xyxy representation"""
        x_min = int(box[0][0])
        y_min = int(box[1][1])
        x_max = int(box[2][0])
        y_max = int(box[3][1])

        return [x_min, y_min, x_max, y_max]

    def _make_result_rect(
        self, box: List, rec_res: Tuple, image: np.ndarray, coord_units: str
    ) -> Union[None, Rect]:
        """Builds the Rect object based on the results provided from paddle"""
        x, y, x2, y2 = box[0], box[1], box[2], box[3]
        w, h = x2 - x, y2 - y
        img_h, img_w, _ = image.shape
        if coord_units in ("%", "percent"):
            x *= 100 / img_w
            w *= 100 / img_w
            y *= 100 / img_h
            h *= 100 / img_h

        text = rec_res[0]
        text = "" if str(text) in {" ", "|", "nan"} else text.strip()
        score = rec_res[1]

        if text == "" or score == 0:
            return

        return Rect(
            x=x, y=y, w=w, h=h, text=text, payload={"tesseract_confidence": score}
        )

    def _split_bbox(self, detected_box: List, image: np.ndarray) -> List:
        """Splits a multi-word bounding box into multiple single-word bounding boxes"""
        # get the coords of the mw box and add some margin which helps with text recognition
        # later ;)
        x_min = detected_box[0] - self.snippet_margin_px
        y_min = detected_box[1] - self.snippet_margin_px
        x_max = detected_box[2] + self.snippet_margin_px
        y_max = detected_box[3] + self.snippet_margin_px

        # extract the snippet from the input image
        text_snippet = np.copy(image[y_min:y_max, x_min:x_max])
        img_h, img_w = y_max - y_min, x_max - x_min
        img_area = int(img_h * img_w)

        # find all the connected components in the snippet
        # since the snippet is a close-up image of the text detected, we expect the connected
        # components to be the characters in the snippet
        gray = cv2.medianBlur(cv2.cvtColor(text_snippet, cv2.COLOR_BGR2GRAY), 1)
        thresh = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 23, 7
        )
        (_, _, stats, _) = cv2.connectedComponentsWithStats(thresh, 4, cv2.CV_32S)

        # filter out the small components
        component_bboxes = []
        for i in range(len(stats)):
            x = stats[i, cv2.CC_STAT_LEFT]
            y = stats[i, cv2.CC_STAT_TOP]
            w = stats[i, cv2.CC_STAT_WIDTH]
            h = stats[i, cv2.CC_STAT_HEIGHT]
            area = stats[i, cv2.CC_STAT_AREA]

            if h > img_h * 0.3 and area < img_area * 0.5 and w > 0:
                component_bboxes.append([x, y, x + w, y + h])
        component_bboxes = np.array(component_bboxes)

        # sort the component bboxes horizontally according to geometrical position order
        # calculate the distances between consecutive boxes
        component_bboxes = component_bboxes[component_bboxes[:, 0].argsort()]
        distances = component_bboxes[1:, 0] - component_bboxes[:-1, 2]
        distances = distances.reshape(-1, 1)

        # cluster the distances in two clusters
        # there are more characters in a snippet than there are words
        # the cluster with the least samples is the one that represents
        # word-word distances
        kmeans = KMeans(n_clusters=2, random_state=0).fit(distances)
        labels = kmeans.labels_
        counts = np.bincount(labels)
        word_space_label = np.argmin(counts)

        # split the multi-word bounding box based on the clusters we calculated
        new_bboxes = [[x_min, y_min, None, y_max]]
        for idx, cb in enumerate(component_bboxes[:-1]):
            if labels[idx] == word_space_label:
                word_xmax = int(x_min + cb[2] + distances[idx])
                new_bboxes[-1][2] = x_min + cb[2]
                new_bboxes.append([word_xmax, y_min, None, y_max])
        new_bboxes[-1][2] = x_max

        # creat a snippet for each new bounding box
        snippets = []
        for b in new_bboxes:
            snippets.append(np.copy(image[b[1] : b[3], b[0] - 2 : b[2] + 2]))

        # perform recognition on the new snippets
        # if no text was recognised, throw the snippet away
        rec_results = []
        snippets_results = self.api.ocr(snippets, det=False, cls=False)
        for idx in range(len(snippets)):
            if len(snippets_results[idx]) > 0:
                rec_results.append([new_bboxes[idx], snippets_results[idx]])
            else:
                del new_bboxes[idx]

        return rec_results